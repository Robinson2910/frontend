import PrivacyPolicy from "./pages/PrivacyPolicy";
import CookiePolicy from "./pages/CookiePolicy";
function App() {
  return (
    <div>
      <PrivacyPolicy />
      {/* <CookiePolicy /> */}
    </div>
  );
}

export default App;
