import DragDrop from "./components/DragDrop";
function App() {
  return (
    <div>
      <DragDrop />
    </div>
  );
}

export default App;
